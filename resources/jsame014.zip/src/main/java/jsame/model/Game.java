/*
 *  This software is copyright (c) 2009 Gabor Bata.
 *
 *  Permission is hereby granted, free of charge, to any person
 *  obtaining a copy of this software and associated documentation files
 *  (the "Software"), to deal in the Software without restriction,
 *  including without limitation the rights to use, copy, modify, merge,
 *  publish, distribute, sublicense, and/or sell copies of the Software,
 *  and to permit persons to whom the Software is furnished to do so,
 *  subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be
 *  included in all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 *  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
 *  BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
 *  ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 *  CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 *  SOFTWARE.
 */
package jsame.model;

public class Game {
    private static final int BONUS_POINTS = 1000;

    private final int width;
    private final int height;
    private final int size;
    private final int colors;
    private final int[] table;

    private int score;
    private boolean bonusAdded;

    public Game(final int width, final int height, final int colors) {
        this.width = width;
        this.height = height;
        this.colors = colors;
        this.size = width * height;
        table = new int[size];
        reset();
    }

    public void reset() {
        score = 0;
        bonusAdded = false;
        GridGenerator.generateGrid(width, height, colors, table);
    }

    public int mark(final int x, final int y) {
        return mark(x, y, getColor(x, y));
    }

    private int mark(final int x, final int y, final int c) {
        if (isMarked(x, y) || c != getColor(x, y) || isRemoved(x, y)) {
            return 0;
        }
        int blocks = 1;
        table[width * y + x] = -1 * getColor(x, y);
        blocks += mark(x - 1, y, getColor(x, y));
        blocks += mark(x, y - 1, getColor(x, y));
        blocks += mark(x + 1, y, getColor(x, y));
        blocks += mark(x, y + 1, getColor(x, y));
        return blocks;
    }

    public boolean isFinished() {
        int remainingBlocks = 0;
        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                if (isRemoved(x, y)) {
                    continue;
                }
                remainingBlocks++;
                int color = getColor(x, y);
                if (getColor(x - 1, y) == color
                        || getColor(x, y - 1) == color
                        || getColor(x + 1, y) == color
                        || getColor(x, y + 1) == color) {
                    return false;
                }
            }
        }

        if (remainingBlocks == 0 && !bonusAdded) {
            bonusAdded = true;
            score += BONUS_POINTS;
        }
        return true;
    }

    public void unmark() {
        for (int i = 0; i < size; i++) {
            table[i] = Math.abs(table[i]);
        }
    }

    public void remove() {
        int removed = 0;
        for (int i = 0; i < size; i++) {
            if (table[i] < 0) {
                removed++;
            }
        }
        if (removed < 2) {
            return;
        }
        for (int i = 0; i < size; i++) {
            if (table[i] < 0) {
                table[i] = 0;
            }
        }
        shiftVertical();
        shiftHorizontal();
        score += countPoints(removed);
    }

    private void swap(final int x1, final int y1, final int x2, final int y2) {
        int pos1 = width * y1 + x1;
        int pos2 = width * y2 + x2;
        int temp = table[pos1];
        table[pos1] = table[pos2];
        table[pos2] = temp;
    }

    private void shiftVertical() {
        boolean canMove;
        for (int x = 0; x < width; x++) {
            canMove = true;
            while (canMove) {
                canMove = false;
                for (int y = 1; y < height; y++) {
                    if (isRemoved(x, y) && !isRemoved(x, y - 1)) {
                        swap(x, y, x, y - 1);
                        canMove = true;
                    }
                }
            }
        }
    }

    private void shiftHorizontal() {
        boolean canMove = true;
        while (canMove) {
            canMove = false;
            for (int x = 1; x < width; x++) {
                if (isRemoved(x - 1, height - 1) && !isRemoved(x, height - 1)) {
                    for (int y = 0; y < height; y++) {
                        swap(x, y, x - 1, y);
                    }
                    canMove = true;
                }
            }
        }
    }

    public boolean isMarked(final int x, final int y) {
        return getState(x, y) < 0 ? true : false;
    }

    public boolean isRemoved(final int x, final int y) {
        return getState(x, y) == 0 ? true : false;
    }

    public int getColor(final int x, final int y) {
        return Math.abs(getState(x, y));
    }

    public int getState(final int x, final int y) {
        if (x < 0 || y < 0 || x > width - 1 || y > height - 1) {
            return 0;
        }
        return table[width * y + x];
    }

    public int[] getTable() {
        return table;
    }

    public int countPoints(final int removed) {
        return (int) Math.pow(removed - 2, 2);
    }

    public int getScore() {
        return score;
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    public int getColors() {
        return colors;
    }

    public int getSize() {
        return size;
    }

}
