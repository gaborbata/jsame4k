/*
 *  This software is copyright (c) 2009 Gabor Bata.
 *
 *  Permission is hereby granted, free of charge, to any person
 *  obtaining a copy of this software and associated documentation files
 *  (the "Software"), to deal in the Software without restriction,
 *  including without limitation the rights to use, copy, modify, merge,
 *  publish, distribute, sublicense, and/or sell copies of the Software,
 *  and to permit persons to whom the Software is furnished to do so,
 *  subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be
 *  included in all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 *  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
 *  BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
 *  ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 *  CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 *  SOFTWARE.
 */
package jsame;

import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.plaf.ColorUIResource;
import javax.swing.plaf.metal.DefaultMetalTheme;
import javax.swing.plaf.metal.MetalLookAndFeel;

import jsame.ui.JSameFrame;

public class JSame {

    public static void main(final String[] args) {

        MetalLookAndFeel.setCurrentTheme(new DefaultMetalTheme() {
            private final ColorUIResource primary1 = new ColorUIResource(0x4d6781);
            private final ColorUIResource primary2 = new ColorUIResource(0x7a96b0);
            private final ColorUIResource primary3 = new ColorUIResource(0xbac9da);
            private final ColorUIResource secondary1 = new ColorUIResource(0x000000);
            private final ColorUIResource secondary2 = new ColorUIResource(0xaaaaaa);
            private final ColorUIResource secondary3 = new ColorUIResource(0xefefef);

            protected ColorUIResource getPrimary1() {
                return primary1;
            }

            protected ColorUIResource getPrimary2() {
                return primary2;
            }

            protected ColorUIResource getPrimary3() {
                return primary3;
            }

            protected ColorUIResource getSecondary1() {
                return secondary1;
            }

            protected ColorUIResource getSecondary2() {
                return secondary2;
            }

            protected ColorUIResource getSecondary3() {
                return secondary3;
            }

        });

        try {
            UIManager.put("swing.boldMetal", Boolean.FALSE);
            UIManager.setLookAndFeel("javax.swing.plaf.metal.MetalLookAndFeel");
        } catch (Exception e) {
            e.printStackTrace();
        }
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                JSameFrame.getInstance();
            }
        });
    }
}
