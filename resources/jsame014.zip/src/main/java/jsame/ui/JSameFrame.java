/*
 *  This software is copyright (c) 2009 Gabor Bata.
 *
 *  Permission is hereby granted, free of charge, to any person
 *  obtaining a copy of this software and associated documentation files
 *  (the "Software"), to deal in the Software without restriction,
 *  including without limitation the rights to use, copy, modify, merge,
 *  publish, distribute, sublicense, and/or sell copies of the Software,
 *  and to permit persons to whom the Software is furnished to do so,
 *  subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be
 *  included in all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 *  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
 *  BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
 *  ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 *  CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 *  SOFTWARE.
 */
package jsame.ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Rectangle;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JPanel;
import javax.swing.border.Border;

import jsame.model.Game;
import jsame.ui.action.BlockListener;
import jsame.ui.action.MenuAction;

public class JSameFrame extends JFrame {
    public static final String PROGRAM_NAME = "JSame";

    public static final String PROGRAM_VERSION = "0.1.4";

    private static final long serialVersionUID = -1745214483676501424L;

    private static volatile JSameFrame INSTANCE;

    private static final Border LINE_BORDER = BorderFactory.createLineBorder(new Color(0xAAAAAA));
    private static final Border TABLE_BORDER = BorderFactory.createLineBorder(new Color(0x262c4b), 4);

    private final Game game = new Game(20, 15, 4);
    private final JLabel score = new JLabel("", JLabel.CENTER);
    private final JLabel marked = new JLabel("", JLabel.CENTER);

    private final TableCanvas canvas;

    private JSameFrame() {
        super(PROGRAM_NAME);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setIconImage(TableGraphics.getProgramImage());

        //menubar
        JMenu gameMenu = new JMenu("Game");
        gameMenu.setMnemonic(KeyEvent.VK_G);
        gameMenu.add(MenuAction.ACTION_NEW);
        gameMenu.addSeparator();
        gameMenu.add(MenuAction.ACTION_EXIT);

        JMenu helpMenu = new JMenu("Help");
        helpMenu.setMnemonic(KeyEvent.VK_H);
        helpMenu.add(MenuAction.ACTION_HELP);
        helpMenu.add(MenuAction.ACTION_ABOUT);

        JMenuBar menuBar = new JMenuBar();
        menuBar.add(gameMenu);
        menuBar.add(helpMenu);
        setJMenuBar(menuBar);

        //canvas
        canvas = new TableCanvas(game.getWidth(), game.getHeight(), game.getTable());
        MouseAdapter adapter = new BlockListener(this);
        canvas.addMouseListener(adapter);
        canvas.addMouseMotionListener(adapter);
        JPanel canvasPanel = new JPanel(new GridLayout(1, 1, 0, 0));
        canvasPanel.setBorder(TABLE_BORDER);
        canvasPanel.add(canvas);

        //create statusbar
        JPanel status = new JPanel(new GridLayout(1, 0, 0, 0));
        marked.setBorder(LINE_BORDER);
        score.setBorder(LINE_BORDER);
        status.add(marked);
        status.add(score);

        //init statusbar values
        showMarked(0);
        showScore();

        getContentPane().add(canvasPanel, BorderLayout.CENTER);
        getContentPane().add(status, BorderLayout.SOUTH);

        setResizable(false);
        pack();
        centerScreen();
        setVisible(true);
    }

    public static JSameFrame getInstance() {
        if (INSTANCE == null) {
            synchronized (JSameFrame.class) {
                if (INSTANCE == null) {
                    INSTANCE = new JSameFrame();
                }
            }
        }
        return INSTANCE;
    }

    private void centerScreen() {
        Dimension dim = getToolkit().getScreenSize();
        Rectangle abounds = getBounds();
        setLocation((dim.width - abounds.width) / 2, (dim.height - abounds.height) / 2);
    }

    public void refreshTable() {
        canvas.repaint();
    }

    public Game getGame() {
        return game;
    }

    public void showScore() {
        score.setText(String.format("Score: %d", game.getScore()));
    }

    public void showMarked(final int marked) {
        if (marked > 1) {
            this.marked.setText(String.format("Marked: %d (%d points)", marked, game.countPoints(marked)));
        } else {
            this.marked.setText("");
        }
    }

    public void gameFinished() {
        if (canvas.isEnabled()) {
            showScore();
            canvas.setEnabled(false);
            MessageDialog.showMessage(this, "Game Over!", PROGRAM_NAME);
        }
    }

    public void newGame() {
        getGame().reset();
        canvas.setEnabled(true);
        refreshTable();
        showMarked(0);
        showScore();
    }

}
