/*
 *  This software is copyright (c) 2009 Gabor Bata.
 *
 *  Permission is hereby granted, free of charge, to any person
 *  obtaining a copy of this software and associated documentation files
 *  (the "Software"), to deal in the Software without restriction,
 *  including without limitation the rights to use, copy, modify, merge,
 *  publish, distribute, sublicense, and/or sell copies of the Software,
 *  and to permit persons to whom the Software is furnished to do so,
 *  subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be
 *  included in all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 *  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
 *  BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
 *  ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 *  CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 *  SOFTWARE.
 */
package jsame.ui;

import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;

public class TableGraphics {
    public static final int BLOCK_SIZE = 26;

    private static final double COLOR_FACTOR = 0.7;

    private static final Color COLOR_RED    = new Color(0x914E3B);
    private static final Color COLOR_GREEN  = new Color(0x7B8376);
    private static final Color COLOR_BLUE   = new Color(0x3D6287);
    private static final Color COLOR_YELLOW = new Color(0xAF8652);
    private static final Color COLOR_BACK   = new Color(0x262c4b);


    private static Image[] blockGraphics = new Image[9];
    static {
        blockGraphics[0] = createBlockImage(brighter(COLOR_YELLOW), true);
        blockGraphics[1] = createBlockImage(brighter(COLOR_BLUE), true);
        blockGraphics[2] = createBlockImage(brighter(COLOR_GREEN), true);
        blockGraphics[3] = createBlockImage(brighter(COLOR_RED), true);
        blockGraphics[4] = createBlockImage(COLOR_BACK, false);
        blockGraphics[5] = createBlockImage(COLOR_RED, false);
        blockGraphics[6] = createBlockImage(COLOR_GREEN, false);
        blockGraphics[7] = createBlockImage(COLOR_BLUE, false);
        blockGraphics[8] = createBlockImage(COLOR_YELLOW, false);
    }

    private static Color brighter(Color color) {
        int r = color.getRed();
        int g = color.getGreen();
        int b = color.getBlue();
        int i = (int) (1.0 / (1.0 - COLOR_FACTOR));
        if (r == 0 && g == 0 && b == 0) {
            return new Color(i, i, i);
        }
        if (r > 0 && r < i) {
            r = i;
        }
        if (g > 0 && g < i) {
            g = i;
        }
        if (b > 0 && b < i) {
            b = i;
        }
        return new Color(Math.min((int) (r / COLOR_FACTOR), 255), Math.min(
                (int) (g / COLOR_FACTOR), 255), Math.min(
                (int) (b / COLOR_FACTOR), 255));
    }

    private static Color darker(Color color) {
        return new Color(Math.max((int) (color.getRed() * COLOR_FACTOR), 0),
                Math.max((int) (color.getGreen() * COLOR_FACTOR), 0), Math.max(
                        (int) (color.getBlue() * COLOR_FACTOR), 0));
    }

    private static Image createBlockImage(final Color color, final boolean marked) {
        Image image = new BufferedImage(BLOCK_SIZE, BLOCK_SIZE,
                BufferedImage.TYPE_INT_RGB);
        Graphics g = image.getGraphics();

        Color original = color;
        Color brighter = brighter(original);
        Color darker = darker(original);

        Graphics2D g2d = (Graphics2D) g;
        GradientPaint gp = new GradientPaint(2, 2, original, BLOCK_SIZE - 4, BLOCK_SIZE - 4,
                brighter);
        g2d.setPaint(gp);
        g2d.fillRect(2, 2, BLOCK_SIZE - 4, BLOCK_SIZE - 4);

        g.setColor(brighter);
        g.drawLine(1, BLOCK_SIZE - 3, 1, 1);
        g.drawLine(1, 1, BLOCK_SIZE - 3, 1);

        g.setColor(darker);
        g.drawLine(0, BLOCK_SIZE - 1, BLOCK_SIZE - 1, BLOCK_SIZE - 1);
        g.drawLine(BLOCK_SIZE - 1, BLOCK_SIZE - 1, BLOCK_SIZE - 1, 0);

        g.setColor(original);
        g.drawRect(0, 0, BLOCK_SIZE - 2, BLOCK_SIZE - 2);

        if (marked) {
            g.setColor(darker);
            g.fillRect(8, 8, BLOCK_SIZE - 16, BLOCK_SIZE - 16);
        }

        return image;
    }

    public static Image getBlockImage(int colorIndex) {
        return blockGraphics[colorIndex + 4];
    }

    public static Image getProgramImage() {
        Image image = new BufferedImage(16, 16, BufferedImage.TYPE_INT_RGB);
        Graphics g = image.getGraphics();
        g.setColor(COLOR_RED);
        g.fill3DRect(1, 1, 7, 7, true);
        g.setColor(COLOR_GREEN);
        g.fill3DRect(8, 1, 7, 7, true);
        g.setColor(COLOR_BLUE);
        g.fill3DRect(1, 8, 7, 7, true);
        g.setColor(COLOR_YELLOW);
        g.fill3DRect(8, 8, 7, 7, true);
        g.setColor(COLOR_BACK);
        g.drawRect(0, 0, 15, 15);
        return image;
    }
}
