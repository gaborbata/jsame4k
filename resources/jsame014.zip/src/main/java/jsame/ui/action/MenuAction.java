/*
 *  This software is copyright (c) 2009 Gabor Bata.
 *
 *  Permission is hereby granted, free of charge, to any person
 *  obtaining a copy of this software and associated documentation files
 *  (the "Software"), to deal in the Software without restriction,
 *  including without limitation the rights to use, copy, modify, merge,
 *  publish, distribute, sublicense, and/or sell copies of the Software,
 *  and to permit persons to whom the Software is furnished to do so,
 *  subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be
 *  included in all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 *  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
 *  BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
 *  ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 *  CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 *  SOFTWARE.
 */
package jsame.ui.action;

import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

import javax.swing.AbstractAction;
import javax.swing.KeyStroke;

import jsame.ui.JSameFrame;
import jsame.ui.MessageDialog;

public class MenuAction extends AbstractAction {
    private static final long serialVersionUID = 5173808190650730271L;

    private static enum Command {
        NEW, EXIT, HELP, ABOUT
    }

    private static String HELP_MESSAGE =
        "The objective of the game is to clear the field by removing groups of pieces of the same colour. " +
        "You get points for each group you remove and the larger the group, the more points you get. " +
        "To get the highest score you need to make large blocks of one colour." +
        "<br><br>" +
        "Pieces can be removed when there is a block of at least two pieces of the same colour. " +
        "These pieces will be marked when you move the mouse over them, " +
        "then they can be removed simply by clicking them with the mouse. " +
        "After a block is removed, the pieces above it drop down to fill the empty space. " +
        "When a column is empty, all columns right of it are shifted to the left. " +
        "When there are no more blocks of two or more pieces left, the game is over. " +
        "<br>" +
        "The points of a marked block of pieces are calculated by the formula (<i>n</i> &minus; 2)<sup>2</sup>, " +
        "where <i>n</i> is the number of pieces. " +
        "So try to remove as many pieces at a time as possible to get a higher score. " +
        "When there are no pieces left at the end of the game, you'll get a 1000 points bonus.";

    private static String ABOUT_MESSAGE =
        "<b>" + JSameFrame.PROGRAM_NAME + "</b><br>" +
        "version: " + JSameFrame.PROGRAM_VERSION + "<br>" +
        "Copyright &copy; 2009 Gabor Bata<br>" +
        "All rights reserved.<br>" +
        "<br>" +
        "Portions copyright Simon Tatham, Richard Boulton, James Harvey, Mike Pinna,<br>" +
        "Jonas Kolker, Dariusz Olszewski, Michael Schierl, Lambros Lambrou and<br>" +
        "Bernd Schmidt.<br>" +
        "<br>" +
        "Permission is hereby granted, free of charge, to any person<br>" +
        "obtaining a copy of this software and associated documentation files<br>" +
        "(the \"Software\"), to deal in the Software without restriction,<br>" +
        "including without limitation the rights to use, copy, modify, merge,<br>" +
        "publish, distribute, sublicense, and/or sell copies of the Software,<br>" +
        "and to permit persons to whom the Software is furnished to do so,<br>" +
        "subject to the following conditions:<br>" +
        "<br>" +
        "The above copyright notice and this permission notice shall be<br>" +
        "included in all copies or substantial portions of the Software.<br>" +
        "<br>" +
        "THE SOFTWARE IS PROVIDED \"AS IS\", WITHOUT WARRANTY OF ANY KIND,<br>" +
        "EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF<br>" +
        "MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND<br>" +
        "NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS<br>" +
        "BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN<br>" +
        "ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN<br>" +
        "CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE<br>" +
        "SOFTWARE.";

    public static final MenuAction ACTION_NEW = new MenuAction("New Game", Command.NEW, KeyStroke.getKeyStroke(KeyEvent.VK_N, ActionEvent.CTRL_MASK));
    public static final MenuAction ACTION_EXIT = new MenuAction("Exit", Command.EXIT, KeyStroke.getKeyStroke(KeyEvent.VK_F4, ActionEvent.ALT_MASK));
    public static final MenuAction ACTION_HELP = new MenuAction("Help", Command.HELP, KeyStroke.getKeyStroke(KeyEvent.VK_F1, 0));
    public static final MenuAction ACTION_ABOUT = new MenuAction("About", Command.ABOUT, null);

    public MenuAction(String text, Command command, KeyStroke accelerator) {
        super(text);
        putValue(SHORT_DESCRIPTION, text);
        putValue(ACTION_COMMAND_KEY, command.name());
        if (accelerator != null) {
            putValue(ACCELERATOR_KEY, accelerator);
        }
    }

    @Override
    public void actionPerformed(ActionEvent event) {
        String command = event.getActionCommand();
        JSameFrame frame = JSameFrame.getInstance();
        if (Command.NEW.name().equals(command)) {
            frame.newGame();
        } else if (Command.EXIT.name().equals(command)) {
            System.exit(0);
        } else if (Command.HELP.name().equals(command)) {
            showHelp(frame);
        } else if (Command.ABOUT.name().equals(command)) {
            showAbout(frame);
        }
    }

    private void showHelp(JSameFrame parent) {
        MessageDialog.showHtmlMessage(parent, HELP_MESSAGE, "Help", 550);
    }


    private void showAbout(JSameFrame parent) {
        MessageDialog.showHtmlMessage(parent, ABOUT_MESSAGE, "About", 500);
    }
}
