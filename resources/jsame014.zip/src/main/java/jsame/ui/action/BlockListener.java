/*
 *  This software is copyright (c) 2009 Gabor Bata.
 *
 *  Permission is hereby granted, free of charge, to any person
 *  obtaining a copy of this software and associated documentation files
 *  (the "Software"), to deal in the Software without restriction,
 *  including without limitation the rights to use, copy, modify, merge,
 *  publish, distribute, sublicense, and/or sell copies of the Software,
 *  and to permit persons to whom the Software is furnished to do so,
 *  subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be
 *  included in all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 *  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
 *  BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
 *  ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 *  CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 *  SOFTWARE.
 */
package jsame.ui.action;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

import jsame.ui.JSameFrame;
import jsame.ui.TableGraphics;

public class BlockListener extends MouseAdapter implements MouseListener, MouseMotionListener {
    private final JSameFrame frame;
    private int tempX = -1;
    private int tempY = -1;

    public BlockListener(final JSameFrame frame) {
        this.frame = frame;
    }

    @Override
    public void mouseMoved(MouseEvent event) {
        markBlocks(event.getX(), event.getY(), false);
    }

    @Override
    public void mouseEntered(MouseEvent event) {
        markBlocks(event.getX(), event.getY(), false);
    }

    @Override
    public void mouseReleased(MouseEvent event) {
        markBlocks(event.getX(), event.getY(), true);
    }

    @Override
    public void mousePressed(MouseEvent event) {
        removeBlocks(event.getX(), event.getY());
    }

    @Override
    public void mouseExited(MouseEvent event) {
        unmarkBlocks(event.getX(), event.getY(), true);
    }

    @Override
    public void mouseDragged(MouseEvent event) {
        unmarkBlocks(event.getX(), event.getY(), false);
    }

    private void markBlocks(final int eventX, final int eventY, boolean force) {
        int x = eventX < 0 ? -1 : eventX / TableGraphics.BLOCK_SIZE;
        int y = eventY < 0 ? -1 : eventY / TableGraphics.BLOCK_SIZE;
        if (((tempX != x || tempY != y) && !frame.getGame().isMarked(x, y)) || force) {
            if (frame.getGame().isRemoved(x, y)
                    && frame.getGame().isRemoved(tempX, tempY)) {
                tempX = x;
                tempY = y;
                return;
            }
            frame.getGame().unmark();
            int marked = frame.getGame().mark(x, y);
            frame.refreshTable();
            frame.showMarked(marked);
            tempX = x;
            tempY = y;
        }
    }

    private void unmarkBlocks(final int eventX, final int eventY, boolean force) {
        int x = eventX < 0 ? -1 : eventX / TableGraphics.BLOCK_SIZE;
        int y = eventY < 0 ? -1 : eventY / TableGraphics.BLOCK_SIZE;
        if (tempX != x || tempY != y || force) {
            frame.getGame().unmark();
            frame.refreshTable();
            frame.showMarked(0);
            tempX = x;
            tempY = y;
        }
    }

    private void removeBlocks(final int eventX, final int eventY) {
        int x = eventX < 0 ? -1 : eventX / TableGraphics.BLOCK_SIZE;
        int y = eventY < 0 ? -1 : eventY / TableGraphics.BLOCK_SIZE;
        frame.getGame().remove();

        boolean finished = frame.getGame().isFinished();
        int marked = 0;
        if (!finished) {
            marked = frame.getGame().mark(x, y);
        }
        frame.refreshTable();
        frame.showMarked(marked);
        frame.showScore();
        if (finished) {
            frame.gameFinished();
        }
    }
}
