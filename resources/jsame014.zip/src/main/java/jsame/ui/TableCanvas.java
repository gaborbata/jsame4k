/*
 *  This software is copyright (c) 2009 Gabor Bata.
 *
 *  Permission is hereby granted, free of charge, to any person
 *  obtaining a copy of this software and associated documentation files
 *  (the "Software"), to deal in the Software without restriction,
 *  including without limitation the rights to use, copy, modify, merge,
 *  publish, distribute, sublicense, and/or sell copies of the Software,
 *  and to permit persons to whom the Software is furnished to do so,
 *  subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be
 *  included in all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 *  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
 *  BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
 *  ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 *  CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 *  SOFTWARE.
 */
package jsame.ui;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;

import javax.swing.JComponent;

public class TableCanvas extends JComponent {
    private static final long serialVersionUID = 5371337712689165364L;

    private final Image screenBuffer;
    private final int width;
    private final int height;
    private final int[] table;

    public TableCanvas(int width, int height, int[] table) {
        this.width = width;
        this.height = height;
        this.table = table;
        setPreferredSize(new Dimension(width * TableGraphics.BLOCK_SIZE, height
                * TableGraphics.BLOCK_SIZE));
        screenBuffer = new BufferedImage(width * TableGraphics.BLOCK_SIZE,
                height * TableGraphics.BLOCK_SIZE, BufferedImage.TYPE_INT_RGB);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        paintTable(g);
    }

    private void paintTable(Graphics g) {
        Graphics buffer = screenBuffer.getGraphics();
        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                buffer.drawImage(TableGraphics.getBlockImage(table[width * y
                        + x]), x * TableGraphics.BLOCK_SIZE, y
                        * TableGraphics.BLOCK_SIZE, null, null);
            }
        }
        g.drawImage(screenBuffer, 0, 0, null, null);
    }
}
